AutoComplete XABSL-Patch

Heinrich Mellmann
mellmann@informatik.hu-berlin.de

This is a patched version of AutoComplete 0.3.
The following modification have been done:

AbstractCompletionProvider:CaseInsensitiveComparator - fixed (String)
AutoCompletePopupWindow - set horizontal bar to HORIZONTAL_SCROLLBAR_AS_NEEDED
ParameterizedCompletionDescriptionToolTip:install - adapted the autocompetion of parameters to xabsl syntax (e.g., max(x=1.0, y=2.0);)
CCompletionProvider - added xabslLocalCompletionProvider for handling of "goto" tokens (see also the method getProviderFor(...))
